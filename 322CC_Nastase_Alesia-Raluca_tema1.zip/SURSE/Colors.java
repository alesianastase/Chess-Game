public enum Colors {
    WHITE, BLACK, GRAY
}
