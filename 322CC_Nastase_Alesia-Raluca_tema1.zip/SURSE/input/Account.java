package input;

import java.util.List;

public class Account {
    private String email;
    private String password;
    private int points;
    private List<Integer> games;

    public Account() {} //empty constructor

    //getter
    public String getEmail () {
        return email;
    }

    //setter
    public void setEmail (String email) {
        this.email = email; //takes email param and assigns
        // it to current object's name variable
    }

    public String getPassword () {
        return password;
    }

    public void setPassword (String password) {
        this.password = password;
    }

    public int getPoints () {
        return points;
    }

    public void setPoints (int points) {
        this.points = points;
    }

    public List<Integer> getGames () {
        return games;
    }

    public void setGames (List<Integer> games) {
        this.games = games;
    }
}
