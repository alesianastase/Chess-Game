package input;
import java.util.HashMap;
import java.util.List;

public class Game {
    private long id;
    private List<Player> players;
    private String currentPlayerColor;
    private List<Piece> board;
    private List<Move> moves;

    public Game () {}

    public long getId () {
        return id;
    }

    public void setId (long id) {
        this.id = id;
    }

    public List<Player> getPlayers () {
        return players;
    }

    public void setPlayers (List<Player> players) {
        this.players = players;
    }

    public String getCurrentPlayerColor () {
        return currentPlayerColor;
    }

    public void setCurrentPlayerColor (String currentPlayerColor) {
        this.currentPlayerColor = currentPlayerColor;
    }

    public List<Piece> getBoard () {
        return board;
    }

    public void setBoard (List<Piece> board) {
        this.board = board;
    }

    public List<Move> getMoves () {
        return moves;
    }

    public void setMoves (List<Move> moves) {
        this.moves = moves;
    }

}
