package input;

public class Move {
    private String playerColor;
    private String from;
    private String to;

    public Move (String playerColor, String from, String to) {
        this.playerColor = playerColor;
        this.from = from;
        this.to = to;
    }

    public String getPlayerColor () {
        return playerColor;
    }

    public void setPlayerColor (String playerColor) {
        this.playerColor = playerColor;
    }

    public String getFrom () {
        return from;
    }

    public void setFrom (String from) {
        this.from = from;
    }

    public String getTo () {
        return to;
    }

    public void setTo (String to) {
        this.to = to;
    }



}
