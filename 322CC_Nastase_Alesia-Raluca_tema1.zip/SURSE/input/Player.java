package input;

public class Player {
    private String email;
    private String color;

    public Player (String email, String color) {
        this.email = email;
        this.color = color;
    }

    public String getEmail () {
        return email;
    }

    public void setEmail (String email) {
        this.email = email;
    }

    public String getColor () {
        return color;
    }

    public void setColor (String color) {
        this.color = color;
    }

}
