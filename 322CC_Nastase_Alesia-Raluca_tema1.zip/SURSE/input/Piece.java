package input;

public class Piece {
    private String type;
    private String color;
    private String position;

    public Piece (String type, String color, String position) {
        this.type = type;
        this.position = position;
        this.color = color;
    }

    public String getType () {
        return type;
    }

    public String getColor () {
        return color;
    }

    public String getPosition () {
        return position;
    }
}
